<script src = "<?php echo base_url(); ?>assets/js/scripts/bootstrap.js"></script>
<script src = "<?php echo base_url(); ?>assets/js/scripts/jquery.min.js"></script>
<script src = "<?php echo base_url(); ?>assets/js/scripts/dropdown.js"></script>
<script src = "<?php echo base_url(); ?>assets/js/scripts/sidebar.js"></script>
<script src = "<?php echo base_url(); ?>assets/js/scripts/jquery.dataTables.js"></script>
<script src = "<?php echo base_url(); ?>assets/js/scripts/custom.js"></script>
<script type = "text/javascript">
	$(document).ready(function() {
		$('#table').DataTable();
		$('#table1').DataTable();
	});
	
</script>
