# jquery.printThis_plugin
JQuery plugin for printing
# How to use
Just add a block of jquery code in your app
```javascript
// Include Jquery Library first
// Include jquery-print-this plugin script
<script src="/path/to/jquery.printThis.js"></script>
$(document).ready(function() {
  $('.btn_print').on('click', function(e) {
    $('element').printThis();
  })
});
```
see examples for more details on how to use this plugin
# Download
You can download via npm
```
npm i jquery-plugin-printthis
```
Visit [https://www.npmjs.com/package/jquery-plugin-printthis]
